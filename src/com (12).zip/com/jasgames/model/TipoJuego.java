package com.jasgames.model;

public enum TipoJuego {
    COLORES,
    NUMEROS,
    SERIES,
    FONEMAS
}
