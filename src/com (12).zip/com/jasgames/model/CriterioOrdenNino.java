package com.jasgames.model;

public enum CriterioOrdenNino {
    ID,
    NOMBRE,
    EDAD,
    DIAGNOSTICO
}
